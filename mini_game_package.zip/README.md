# De Kamer • Mini-Game
Een klein HTML-spel in **één bestand**. Werkt lokaal en is direct te hosten.

## Snel hosten op GitHub Pages
1. Maak een GitHub-account (gratis).
2. Nieuwe repository: **Public** → geen extra bestanden nodig.
3. Upload `index.html` naar de **hoofdmap**.
4. Ga naar **Settings → Pages** → *Source*: **Deploy from a branch** → **main** → **/ (root)** → **Save**.
5. Wacht ±30 sec, je site komt beschikbaar op `https://<jouw-gebruikersnaam>.github.io/<repo-naam>/`.

## Snel hosten op Itch.io
1. Maak een gratis account op Itch.io.
2. Nieuwe project: **Kind of project** = **HTML** / **HTML5**.
3. Upload `index.html` (eventueel als `.zip`).
4. Vink aan: **This file will be played in the browser** → **Save/Publish**.
